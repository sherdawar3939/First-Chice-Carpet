"use client";
import ContactForm from "@/components/ContactForm";
import ContactUsSection from "@/components/ContactUsSection";
import React from "react";

const page = () => {
  return (
    <div>
      <ContactUsSection />
      <ContactForm />
    </div>
  );
};

export default page;
