const catergory = `
Wall to Wall carpet
Office carpet
Home carpet
Living room carpet
Mosque carpet
Residential carpet
Hotel carpet
Living room curtain
Sheer curtain
Master room curtain
Motorized curtain
Roman blinds
Sisal rugs
Area rugs
Round rugs
Shaggy rugs
Custom rugs
Vinyl flooring
Parquet flooring
LVT flooring


categroy:
carpets
curtains
rugs
flooring
`;
