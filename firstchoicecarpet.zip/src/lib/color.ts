export const primarycolor = "#14B1E7";
export const secondarycolor = "#FFC100";
export const green = "#28B01C";
export const gray = "#E8E8E6";
export const white = "#FFFFFF";
